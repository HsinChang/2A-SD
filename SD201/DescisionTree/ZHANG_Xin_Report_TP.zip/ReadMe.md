This TP is written and should be running in Python 3.

The PDF report file is the converted version of the Jupyter Notebook.

The three .py file are code extracted from the Notebook for standalone running.

The \img and \skysurvey are for the proper display of the Jupyter Notebook in another computer.

Tree.pdf shows the original tree.

Tree_modified.pdf shows the best tree by changing parameters.

Tree_pruned.pdf shows the tree got by post-pruning function implemented.